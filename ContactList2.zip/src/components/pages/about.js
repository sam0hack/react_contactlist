import React from "react";

export default props => {
  return <div>Hello</div>;
};
